import { useState, useCallback } from "react";

export interface DailyRecord {
  date: string;
  count: number;
  goal: number;
  reached: boolean;
}

export interface UserData {
  name: string;
  todayCount: number;
  totalCount: number;
  streak: number;
  lastDate: string;
  hourlyCount: number;
  lastHour: number;
  level: string;
  dailyGoal: number;
  history: DailyRecord[];
  createdAt: string;
}

const STORAGE_KEY = "tasbeeh-user-v2";

function getDefaultData(name: string): UserData {
  return {
    name,
    todayCount: 0,
    totalCount: 0,
    streak: 0,
    lastDate: "",
    hourlyCount: 0,
    lastHour: -1,
    level: "beginner",
    dailyGoal: 100,
    history: [],
    createdAt: new Date().toISOString(),
  };
}

function loadData(): UserData | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as UserData;
  } catch {
    return null;
  }
}

function saveData(data: UserData) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

function getLevel(total: number): string {
  if (total >= 50000) return "master";
  if (total >= 20000) return "expert";
  if (total >= 10000) return "advanced";
  if (total >= 3000) return "intermediate";
  return "beginner";
}

function getTodayString(): string {
  return new Date().toDateString();
}

export function useUserData() {
  const [user, setUser] = useState<UserData | null>(() => loadData());

  const initUser = useCallback((name: string) => {
    const existing = loadData();
    if (existing && existing.name === name) {
      // check day change
      const today = getTodayString();
      if (existing.lastDate !== today) {
        // save yesterday
        if (existing.lastDate) {
          existing.history.push({
            date: existing.lastDate,
            count: existing.todayCount,
            goal: existing.dailyGoal,
            reached: existing.todayCount >= existing.dailyGoal,
          });
          // keep only last 30
          if (existing.history.length > 30) existing.history = existing.history.slice(-30);
        }
        existing.todayCount = 0;
        existing.hourlyCount = 0;
        existing.lastHour = -1;
        existing.lastDate = today;
        if (existing.streak > 0) {
          // check if yesterday reached goal
          const yesterday = new Date();
          yesterday.setDate(yesterday.getDate() - 1);
          const yestStr = yesterday.toDateString();
          const yestRecord = existing.history.find((h) => h.date === yestStr);
          if (!yestRecord || !yestRecord.reached) {
            existing.streak = 0;
          }
        }
      }
      existing.level = getLevel(existing.totalCount);
      saveData(existing);
      setUser(existing);
      return existing;
    }
    const fresh = getDefaultData(name);
    fresh.lastDate = getTodayString();
    saveData(fresh);
    setUser(fresh);
    return fresh;
  }, []);

  const increment = useCallback(() => {
    setUser((prev) => {
      if (!prev) return prev;
      const now = new Date();
      const today = now.toDateString();
      const currentHour = now.getHours();
      let next = { ...prev };

      if (next.lastDate !== today) {
        if (next.lastDate) {
          next.history = [
            ...next.history,
            { date: next.lastDate, count: next.todayCount, goal: next.dailyGoal, reached: next.todayCount >= next.dailyGoal },
          ];
          if (next.history.length > 30) next.history = next.history.slice(-30);
        }
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        const yestRecord = next.history.find((h) => h.date === yesterday.toDateString());
        if (!yestRecord || !yestRecord.reached) {
          next.streak = 0;
        }
        next.todayCount = 0;
        next.hourlyCount = 0;
        next.lastDate = today;
      }

      if (next.lastHour !== currentHour) {
        next.hourlyCount = 0;
        next.lastHour = currentHour;
      }

      next.todayCount += 1;
      next.totalCount += 1;
      next.hourlyCount += 1;
      next.level = getLevel(next.totalCount);

      saveData(next);
      return next;
    });
  }, []);

  const setGoal = useCallback((goal: number) => {
    setUser((prev) => {
      if (!prev) return prev;
      const next = { ...prev, dailyGoal: Math.max(10, Math.min(10000, goal)) };
      saveData(next);
      return next;
    });
  }, []);

  const getWeeklyData = useCallback(() => {
    if (!user) return [];
    const result: { day: string; count: number }[] = [];
    const lang = localStorage.getItem("tasbeeh-lang") === "en" ? "en" : "ar";
    const days = lang === "en" 
      ? ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"] 
      : ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = d.toDateString();
      const record = user.history.find((h) => h.date === dateStr);
      const dayIndex = d.getDay();
      result.push({
        day: days[dayIndex],
        count: record ? record.count : 0,
      });
    }
    return result;
  }, [user]);

  const getFilteredLeaderboard = useCallback(
    (filter: "today" | "week" | "month" | "all") => {
      if (!user) return [];
      const lang = localStorage.getItem("tasbeeh-lang") === "en" ? "en" : "ar";
      // Realistic demo data - small group of active users
      const demoUsers = [
        { id: "1", name: lang === "ar" ? "صالح" : "Salih", today: 156, week: 980, month: 4200, total: 12500, streak: 7, isBot: false },
        { id: "2", name: lang === "ar" ? "عبدالله" : "Abdullah", today: 89, week: 620, month: 2800, total: 8900, streak: 4, isBot: false },
        { id: "3", name: lang === "ar" ? "فاطمة" : "Fatima", today: 45, week: 310, month: 1500, total: 5200, streak: 3, isBot: false },
        { id: "4", name: lang === "ar" ? "ناصر" : "Nasser", today: 23, week: 180, month: 890, total: 3400, streak: 2, isBot: false },
        { id: "5", name: lang === "ar" ? "خالد" : "Khaled", today: 12, week: 95, month: 420, total: 1800, streak: 1, isBot: false },
      ];

      const currentUserEntry = {
        id: "me",
        name: user.name,
        today: user.todayCount,
        week: user.history
          .filter((h) => {
            const d = new Date(h.date);
            const weekAgo = new Date();
            weekAgo.setDate(weekAgo.getDate() - 7);
            return d >= weekAgo;
          })
          .reduce((sum, h) => sum + h.count, user.todayCount),
        month: user.history
          .filter((h) => {
            const d = new Date(h.date);
            const monthAgo = new Date();
            monthAgo.setDate(monthAgo.getDate() - 30);
            return d >= monthAgo;
          })
          .reduce((sum, h) => sum + h.count, user.todayCount),
        total: user.totalCount,
        streak: user.streak,
        isBot: false,
      };

      const all = [...demoUsers, currentUserEntry];

      const sorted = all.sort((a, b) => {
        if (filter === "today") return b.today - a.today;
        if (filter === "week") return b.week - a.week;
        if (filter === "month") return b.month - a.month;
        return b.total - a.total;
      });

      return sorted.map((u, idx) => ({ ...u, rank: idx + 1 }));
    },
    [user]
  );

  const reset = useCallback(() => {
    localStorage.removeItem(STORAGE_KEY);
    setUser(null);
  }, []);

  return { user, initUser, increment, setGoal, getWeeklyData, getFilteredLeaderboard, reset };
}
