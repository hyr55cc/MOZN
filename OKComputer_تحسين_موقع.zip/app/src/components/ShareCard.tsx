import { useRef, useCallback, useState } from "react";
import { useLanguage } from "@/hooks/useLanguage";
import { Download, X, Camera } from "lucide-react";
import html2canvas from "html2canvas";
import { motion, AnimatePresence } from "framer-motion";

interface ShareCardProps {
  name: string;
  todayCount: number;
  totalCount: number;
  streak: number;
  level: string;
}

export default function ShareCard({ name, todayCount, totalCount, streak, level }: ShareCardProps) {
  const { t, lang } = useLanguage();
  const cardRef = useRef<HTMLDivElement>(null);
  const [showPreview, setShowPreview] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);

  const handleDownload = useCallback(async () => {
    if (!cardRef.current) return;
    setIsGenerating(true);
    try {
      const canvas = await html2canvas(cardRef.current, {
        backgroundColor: null,
        scale: 2,
      });
      const link = document.createElement("a");
      link.download = `tasbeeh-${name}-${Date.now()}.png`;
      link.href = canvas.toDataURL("image/png");
      link.click();
    } catch (e) {
      console.error(e);
    } finally {
      setIsGenerating(false);
    }
  }, [name]);

  const levelsAr: Record<string, string> = {
    beginner: "مبتدئ",
    intermediate: "متوسط",
    advanced: "متقدم",
    expert: "خبير",
    master: "مastery",
  };

  return (
    <>
      <button
        onClick={() => setShowPreview(true)}
        className="fixed bottom-5 left-5 z-40 w-12 h-12 rounded-full bg-tasbeeh-accent text-tasbeeh-bg-dark flex items-center justify-center shadow-lg hover:scale-110 transition-transform"
        title={t("shareAchievement")}
      >
        <Camera className="w-5 h-5" />
      </button>

      <AnimatePresence>
        {showPreview && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4"
            onClick={() => setShowPreview(false)}
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="relative"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => setShowPreview(false)}
                className="absolute -top-3 -right-3 z-10 w-8 h-8 rounded-full bg-red-500 text-white flex items-center justify-center shadow-lg"
              >
                <X className="w-4 h-4" />
              </button>

              {/* The card to capture */}
              <div
                ref={cardRef}
                className="w-[340px] rounded-2xl overflow-hidden"
                style={{
                  background: "linear-gradient(135deg, #0f2e22 0%, #1a5f4a 50%, #0a1f17 100%)",
                  border: "2px solid #d4a853",
                }}
              >
                <div className="p-6 text-center">
                  <div className="text-4xl mb-2">🌙</div>
                  <h2
                    className="text-2xl font-black mb-1"
                    style={{ color: "#d4a853" }}
                  >
                    {t("title")}
                  </h2>
                  <p className="text-sm mb-6" style={{ color: "#a8c5b5" }}>
                    {t("subtitle")}
                  </p>

                  <div className="bg-black/20 rounded-xl p-4 mb-4">
                    <div className="text-lg font-bold mb-3" style={{ color: "#e8f5e9" }}>
                      {name}
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      <div className="text-center">
                        <div className="text-2xl font-black" style={{ color: "#d4a853" }}>
                          {todayCount}
                        </div>
                        <div className="text-[10px]" style={{ color: "#6b9b82" }}>
                          {t("todayCount")}
                        </div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-black" style={{ color: "#d4a853" }}>
                          {streak}
                        </div>
                        <div className="text-[10px]" style={{ color: "#6b9b82" }}>
                          {t("streak")}
                        </div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-black" style={{ color: "#d4a853" }}>
                          {totalCount.toLocaleString()}
                        </div>
                        <div className="text-[10px]" style={{ color: "#6b9b82" }}>
                          {t("total")}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-center gap-2">
                    <div
                      className="px-3 py-1 rounded-full text-xs font-bold"
                      style={{ background: "#d4a853", color: "#0a1f17" }}
                    >
                      {lang === "ar" ? levelsAr[level] || level : level}
                    </div>
                    <div className="text-xs" style={{ color: "#6b9b82" }}>
                      {t("shareText")} - {t("title")}
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-4 flex gap-2 justify-center">
                <button
                  onClick={handleDownload}
                  disabled={isGenerating}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-tasbeeh-accent text-tasbeeh-bg-dark font-bold hover:opacity-90 transition-opacity disabled:opacity-50"
                >
                  {isGenerating ? (
                    <div className="w-4 h-4 border-2 border-tasbeeh-bg-dark/30 border-t-tasbeeh-bg-dark rounded-full animate-spin" />
                  ) : (
                    <Download className="w-4 h-4" />
                  )}
                  {t("save")}
                </button>
                <button
                  onClick={() => setShowPreview(false)}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-tasbeeh-bg-dark text-tasbeeh-text-secondary font-bold hover:text-tasbeeh-text-primary transition-colors"
                >
                  <X className="w-4 h-4" />
                  {t("close")}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
