import { useState } from "react";
import { useLanguage } from "@/hooks/useLanguage";
import { Moon, Sparkles } from "lucide-react";
import { motion } from "framer-motion";

export default function WelcomeScreen({ onStart }: { onStart: (name: string) => void }) {
  const { t, dir } = useLanguage();
  const [name, setName] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) onStart(name.trim());
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.4 }}
        className="glass-card p-8 max-w-sm w-full text-center"
      >
        <div className="flex justify-center mb-4">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-tasbeeh-primary-light to-tasbeeh-accent flex items-center justify-center">
            <Moon className="w-8 h-8 text-white" />
          </div>
        </div>
        <h2 className="text-2xl font-bold text-tasbeeh-accent mb-2">{t("welcome")}</h2>
        <p className="text-tasbeeh-text-secondary mb-6">{t("enterName")}</p>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder={t("namePlaceholder")}
            className="w-full px-4 py-3 rounded-xl bg-tasbeeh-bg-card border border-tasbeeh-primary/30 text-tasbeeh-text-primary placeholder:text-tasbeeh-text-muted focus:outline-none focus:border-tasbeeh-accent text-center"
            dir={dir}
          />
          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-gradient-to-r from-tasbeeh-primary-light to-tasbeeh-primary text-white font-bold text-lg hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
          >
            <Sparkles className="w-5 h-5" />
            {t("start")}
          </button>
        </form>
      </motion.div>
    </div>
  );
}
