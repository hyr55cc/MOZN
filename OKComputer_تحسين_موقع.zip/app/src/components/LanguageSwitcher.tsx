import { useLanguage } from "@/hooks/useLanguage";

export default function LanguageSwitcher() {
  const { lang, setLang } = useLanguage();

  return (
    <div className="flex items-center gap-1 bg-tasbeeh-bg-dark/60 rounded-lg p-1">
      <button
        onClick={() => setLang("ar")}
        className={`px-2 py-1 rounded-md text-xs font-bold transition-colors ${
          lang === "ar" ? "bg-tasbeeh-accent text-tasbeeh-bg-dark" : "text-tasbeeh-text-muted hover:text-tasbeeh-text-secondary"
        }`}
      >
        عربي
      </button>
      <button
        onClick={() => setLang("en")}
        className={`px-2 py-1 rounded-md text-xs font-bold transition-colors ${
          lang === "en" ? "bg-tasbeeh-accent text-tasbeeh-bg-dark" : "text-tasbeeh-text-muted hover:text-tasbeeh-text-secondary"
        }`}
      >
        EN
      </button>
    </div>
  );
}
