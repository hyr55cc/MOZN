import { useState } from "react";
import { useLanguage } from "@/hooks/useLanguage";
import { Target, TrendingUp, Award, Settings } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface UserCardProps {
  name: string;
  todayCount: number;
  dailyGoal: number;
  streak: number;
  hourlyCount: number;
  totalCount: number;
  level: string;
  rank: number;
  onSetGoal: (goal: number) => void;
  flash?: boolean;
}

export default function UserCard({
  name,
  todayCount,
  dailyGoal,
  streak,
  hourlyCount,
  totalCount,
  level,
  rank,
  onSetGoal,
  flash = false,
}: UserCardProps) {
  const { t } = useLanguage();
  const [showGoalModal, setShowGoalModal] = useState(false);
  const [tempGoal, setTempGoal] = useState(dailyGoal);

  const progress = Math.min((todayCount / dailyGoal) * 100, 100);
  const goalReached = todayCount >= dailyGoal;

  const levels: Record<string, number> = {
    beginner: 0,
    intermediate: 1,
    advanced: 2,
    expert: 3,
    master: 4,
  };

  const currentLevel = levels[level] ?? 0;

  const handleSaveGoal = () => {
    onSetGoal(tempGoal);
    setShowGoalModal(false);
  };

  const goalOptions = [33, 100, 500, 1000, 5000];

  return (
    <div className="glass-card p-5 relative">
      <div className="flex items-center gap-3 mb-4 pb-4 border-b border-tasbeeh-primary/20">
        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-tasbeeh-primary-light to-tasbeeh-accent flex items-center justify-center text-white font-bold text-xl">
          {name.charAt(0)}
        </div>
        <div className="flex-1">
          <h3 className={`font-bold text-lg text-tasbeeh-text-primary transition-all ${flash ? "user-active-flash" : ""}`}>{name}</h3>
          <div className="flex items-center gap-2">
            <span className="text-xs text-tasbeeh-text-muted">
              {t("level")}: {t(level as any)}
            </span>
            <div className="flex gap-0.5">
              {[0, 1, 2, 3, 4].map((i) => (
                <div
                  key={i}
                  className={`w-2 h-2 rounded-full ${
                    i <= currentLevel ? "bg-tasbeeh-accent" : "bg-tasbeeh-primary/30"
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
        {streak > 0 && (
          <div className="flex flex-col items-center bg-orange-500/10 rounded-lg px-2 py-1 shrink-0">
            <span className="text-xs font-black text-orange-400">🔥{streak}</span>
            <span className="text-[10px] text-orange-400/70">{t("days")}</span>
          </div>
        )}
        <button
          onClick={() => setShowGoalModal(true)}
          className="p-2 rounded-lg bg-tasbeeh-primary/20 text-tasbeeh-accent hover:bg-tasbeeh-primary/30 transition-colors"
          title={t("setGoal")}
        >
          <Settings className="w-4 h-4" />
        </button>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-sm text-tasbeeh-text-secondary">{t("todayProgress")}</span>
          <span className="text-sm font-bold text-tasbeeh-accent">
            {todayCount} / {dailyGoal}
          </span>
        </div>

        <div className="w-full h-2.5 bg-tasbeeh-bg-dark rounded-full overflow-hidden">
          <motion.div
            className={`h-full rounded-full ${goalReached ? "bg-tasbeeh-accent" : "bg-tasbeeh-primary-light"}`}
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>

        {goalReached && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center py-2 px-3 rounded-lg bg-tasbeeh-accent/10 border border-tasbeeh-accent/30"
          >
            <div className="text-tasbeeh-accent font-bold flex items-center justify-center gap-2">
              <Award className="w-4 h-4" />
              {t("goalReached")}!
            </div>
          </motion.div>
        )}

        <div className="grid grid-cols-2 gap-3">
          <div className="bg-tasbeeh-bg-dark/60 rounded-xl p-3 text-center">
            <div className="text-xl font-black text-tasbeeh-accent">#{rank}</div>
            <div className="text-xs text-tasbeeh-text-muted">{t("yourRank")}</div>
          </div>
          <div className="bg-tasbeeh-bg-dark/60 rounded-xl p-3 text-center">
            <div className="text-xl font-black text-tasbeeh-accent">{hourlyCount || "-"}</div>
            <div className="text-xs text-tasbeeh-text-muted">{t("hourlyRate")}</div>
          </div>
        </div>

        <div className="flex items-center justify-between bg-tasbeeh-bg-dark/40 rounded-xl p-3">
          <div className="flex items-center gap-2">
            <Target className="w-4 h-4 text-tasbeeh-accent" />
            <span className="text-sm text-tasbeeh-text-secondary">{t("goal")}</span>
          </div>
          <span className="text-sm font-bold text-tasbeeh-text-primary">{dailyGoal}</span>
        </div>

        <div className="flex items-center justify-between bg-tasbeeh-bg-dark/40 rounded-xl p-3">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-tasbeeh-accent" />
            <span className="text-sm text-tasbeeh-text-secondary">{t("total")}</span>
          </div>
          <span className="text-sm font-bold text-tasbeeh-text-primary">{totalCount.toLocaleString()}</span>
        </div>
      </div>

      <AnimatePresence>
        {showGoalModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4"
            onClick={() => setShowGoalModal(false)}
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="glass-card p-6 max-w-xs w-full"
              onClick={(e) => e.stopPropagation()}
            >
              <h3 className="text-xl font-bold text-tasbeeh-accent mb-4 text-center">{t("setGoal")}</h3>
              <div className="grid grid-cols-2 gap-2 mb-4">
                {goalOptions.map((g) => (
                  <button
                    key={g}
                    onClick={() => setTempGoal(g)}
                    className={`py-2 rounded-lg font-bold text-sm transition-colors ${
                      tempGoal === g
                        ? "bg-tasbeeh-accent text-tasbeeh-bg-dark"
                        : "bg-tasbeeh-bg-dark text-tasbeeh-text-secondary hover:text-tasbeeh-text-primary"
                    }`}
                  >
                    {g}
                  </button>
                ))}
              </div>
              <div className="mb-4">
                <label className="text-xs text-tasbeeh-text-muted block mb-1">{t("customGoal")}</label>
                <input
                  type="number"
                  value={tempGoal}
                  onChange={(e) => setTempGoal(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-full px-3 py-2 rounded-lg bg-tasbeeh-bg-dark border border-tasbeeh-primary/30 text-tasbeeh-text-primary text-center focus:outline-none focus:border-tasbeeh-accent"
                />
              </div>
              <div className="flex gap-2">
                <button
                  onClick={handleSaveGoal}
                  className="flex-1 py-2 rounded-lg bg-tasbeeh-accent text-tasbeeh-bg-dark font-bold hover:opacity-90 transition-opacity"
                >
                  {t("save")}
                </button>
                <button
                  onClick={() => setShowGoalModal(false)}
                  className="flex-1 py-2 rounded-lg bg-tasbeeh-bg-dark text-tasbeeh-text-secondary font-bold hover:text-tasbeeh-text-primary transition-colors"
                >
                  {t("cancel")}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
