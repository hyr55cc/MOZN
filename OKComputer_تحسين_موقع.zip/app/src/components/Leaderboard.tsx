import { useState } from "react";
import { useLanguage } from "@/hooks/useLanguage";
import { Trophy, Flame, TrendingUp, Minus, Copy, Check } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface LeaderboardEntry {
  id: string;
  name: string;
  today: number;
  week: number;
  month: number;
  total: number;
  streak: number;
  isBot: boolean;
  rank: number;
}

interface LeaderboardProps {
  data: LeaderboardEntry[];
  currentUserId: string;
  activeFilter: "today" | "week" | "month" | "all";
  onFilterChange: (filter: "today" | "week" | "month" | "all") => void;
}

export default function Leaderboard({ data, currentUserId, activeFilter, onFilterChange }: LeaderboardProps) {
  const { t } = useLanguage();
  const [expandedUser, setExpandedUser] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const handleCopyLink = () => {
    const url = "https://hyr55cc.github.io/MOZN/";
    navigator.clipboard.writeText(url).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }).catch(() => {
      const textArea = document.createElement("textarea");
      textArea.value = url;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand("copy");
      document.body.removeChild(textArea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const filters: { key: "today" | "week" | "month" | "all"; label: string }[] = [
    { key: "today", label: t("today") },
    { key: "week", label: t("week") },
    { key: "month", label: t("month") },
    { key: "all", label: t("allTime") },
  ];

  const getValue = (u: LeaderboardEntry) => {
    if (activeFilter === "today") return u.today;
    if (activeFilter === "week") return u.week;
    if (activeFilter === "month") return u.month;
    return u.total;
  };

  const getRankColor = (rank: number) => {
    if (rank === 1) return "bg-yellow-500 text-tasbeeh-bg-dark";
    if (rank === 2) return "bg-gray-300 text-tasbeeh-bg-dark";
    if (rank === 3) return "bg-amber-600 text-white";
    return "bg-tasbeeh-bg-dark text-tasbeeh-text-muted";
  };

  return (
    <div className="mt-5">
      {/* Compact Share Section */}
      <div className="flex items-center gap-2 mb-4 px-3 py-2 rounded-xl" style={{ background: "var(--glass-bg)", border: "1px solid var(--border-color)" }}>
        <p className="text-[11px] shrink-0" style={{ color: "var(--text-muted)" }}>
          {t("shareBlessing")}
        </p>
        <div className="flex-1 min-w-0 bg-tasbeeh-bg-dark/40 rounded-md px-2 py-1 text-[10px] truncate" style={{ color: "var(--text-secondary)" }}>
          https://hyr55cc.github.io/MOZN/
        </div>
        <button
          onClick={handleCopyLink}
          className={`shrink-0 px-2.5 py-1 rounded-md text-[10px] font-bold transition-all flex items-center gap-1 ${
            copied
              ? "bg-green-500/20 text-green-400"
              : "bg-tasbeeh-accent/15 text-tasbeeh-accent hover:bg-tasbeeh-accent/25"
          }`}
        >
          {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
          {copied ? t("copied") : t("copy")}
        </button>
      </div>

      <div className="flex items-center gap-2 mb-4">
        <Trophy className="w-5 h-5" style={{ color: "var(--accent)" }} />
        <h3 className="text-lg font-black" style={{ color: "var(--accent)" }}>{t("leaderboard")}</h3>
      </div>

      <div className="flex gap-1 mb-3 p-1 rounded-xl" style={{ background: "rgba(0,0,0,0.15)" }}>
        {filters.map((f) => (
          <button
            key={f.key}
            onClick={() => onFilterChange(f.key)}
            className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-bold transition-colors ${
              activeFilter === f.key
                ? "text-tasbeeh-bg-dark"
                : "hover:text-tasbeeh-text-secondary"
            }`}
            style={
              activeFilter === f.key
                ? { background: "var(--accent)", color: "var(--bg-dark)" }
                : { color: "var(--text-muted)" }
            }
          >
            {f.label}
          </button>
        ))}
      </div>

      <div className="space-y-2">
        <AnimatePresence mode="popLayout">
          {data.map((user) => (
            <motion.div
              key={user.id + activeFilter}
              layout
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className={`leaderboard-row cursor-pointer ${
                user.id === currentUserId ? "border-tasbeeh-accent/40 bg-tasbeeh-primary/10" : ""
              }`}
              style={user.id === currentUserId ? { borderColor: "var(--accent)" } : {}}
              onClick={() => setExpandedUser(expandedUser === user.id ? null : user.id)}
            >
              <div className="flex items-center gap-3">
                <div
                  className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm font-black shrink-0 ${getRankColor(
                    user.rank
                  )}`}
                >
                  {user.rank}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-bold truncate" style={{ color: "var(--text-primary)" }}>
                      {user.name}
                    </span>
                    {user.streak > 0 && (
                      <span className="flex items-center gap-0.5 text-xs text-orange-400">
                        <Flame className="w-3 h-3" />
                        {user.streak} {t(user.streak === 1 ? "day" : "days")}
                      </span>
                    )}
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <div className="font-black text-lg" style={{ color: "var(--accent)" }}>
                    {getValue(user).toLocaleString()}
                  </div>
                </div>

                <div className="shrink-0">
                  {user.rank <= 3 ? (
                    <TrendingUp className="w-4 h-4 text-green-400" />
                  ) : (
                    <Minus className="w-4 h-4" style={{ color: "var(--text-muted)" }} />
                  )}
                </div>
              </div>

              <AnimatePresence>
                {expandedUser === user.id && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="grid grid-cols-4 gap-2 mt-3 pt-3 border-t" style={{ borderColor: "var(--border-color)" }}>
                      <div className="text-center">
                        <div className="text-sm font-bold" style={{ color: "var(--text-primary)" }}>{user.today.toLocaleString()}</div>
                        <div className="text-[10px]" style={{ color: "var(--text-muted)" }}>{t("today")}</div>
                      </div>
                      <div className="text-center">
                        <div className="text-sm font-bold" style={{ color: "var(--text-primary)" }}>{user.week.toLocaleString()}</div>
                        <div className="text-[10px]" style={{ color: "var(--text-muted)" }}>{t("week")}</div>
                      </div>
                      <div className="text-center">
                        <div className="text-sm font-bold" style={{ color: "var(--text-primary)" }}>{user.month.toLocaleString()}</div>
                        <div className="text-[10px]" style={{ color: "var(--text-muted)" }}>{t("month")}</div>
                      </div>
                      <div className="text-center">
                        <div className="text-sm font-bold" style={{ color: "var(--text-primary)" }}>{user.total.toLocaleString()}</div>
                        <div className="text-[10px]" style={{ color: "var(--text-muted)" }}>{t("total")}</div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
