import { useTheme, type ThemeName } from "@/hooks/useTheme";

const themes: { key: ThemeName; label: string; color: string }[] = [
  { key: "green", label: "A", color: "#2d8a6e" },
  { key: "ocean", label: "B", color: "#2e86c1" },
  { key: "twilight", label: "C", color: "#7d5cb3" },
  { key: "earth", label: "D", color: "#8d6e63" },
];

export default function ThemeSwitcher() {
  const { theme, setTheme } = useTheme();

  return (
    <div className="flex items-center gap-1 bg-tasbeeh-bg-card/60 rounded-lg p-1">
      {themes.map((t) => (
        <button
          key={t.key}
          onClick={() => setTheme(t.key)}
          className={`w-6 h-6 rounded-md text-[10px] font-black transition-all border-2 ${
            theme === t.key
              ? "border-tasbeeh-accent scale-110"
              : "border-transparent opacity-60 hover:opacity-100"
          }`}
          style={{ background: t.color }}
          title={t.key}
        />
      ))}
    </div>
  );
}
