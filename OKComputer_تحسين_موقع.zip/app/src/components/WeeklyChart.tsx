import { useLanguage } from "@/hooks/useLanguage";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { TrendingUp } from "lucide-react";

interface WeeklyChartProps {
  data: { day: string; count: number }[];
}

export default function WeeklyChart({ data }: WeeklyChartProps) {
  const { t } = useLanguage();

  const maxCount = Math.max(...data.map((d) => d.count), 1);

  return (
    <div className="glass-card p-5 mt-5">
      <div className="flex items-center gap-2 mb-4">
        <TrendingUp className="w-5 h-5 text-tasbeeh-accent" />
        <h3 className="text-lg font-bold text-tasbeeh-accent">{t("weeklyStats")}</h3>
      </div>

      {data.every((d) => d.count === 0) ? (
        <div className="text-center py-8 text-tasbeeh-text-muted">{t("noData")}</div>
      ) : (
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <XAxis
                dataKey="day"
                tick={{ fill: "#a8c5b5", fontSize: 12 }}
                axisLine={{ stroke: "rgba(45,138,110,0.2)" }}
                tickLine={false}
              />
              <YAxis
                tick={{ fill: "#a8c5b5", fontSize: 12 }}
                axisLine={false}
                tickLine={false}
              />
              <Tooltip
                contentStyle={{
                  background: "rgba(15,46,34,0.95)",
                  border: "1px solid rgba(45,138,110,0.3)",
                  borderRadius: "8px",
                  color: "#e8f5e9",
                  fontSize: "14px",
                }}
                formatter={(value: number) => [value.toLocaleString(), t("todayCount")]}
                labelStyle={{ color: "#d4a853" }}
              />
              <Bar dataKey="count" radius={[6, 6, 0, 0]} animationDuration={800}>
                {data.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={entry.count >= maxCount ? "#d4a853" : "#2d8a6e"}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
}
