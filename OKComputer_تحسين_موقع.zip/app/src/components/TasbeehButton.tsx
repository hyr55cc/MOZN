import { useState, useRef, useCallback } from "react";
import { motion } from "framer-motion";

interface TasbeehButtonProps {
  count: number;
  onTap: () => void;
}

export default function TasbeehButton({ count, onTap }: TasbeehButtonProps) {
  const [ripples, setRipples] = useState<{ id: number; x: number; y: number }[]>([]);
  const btnRef = useRef<HTMLButtonElement>(null);
  const rippleId = useRef(0);

  const handleClick = useCallback(
    (e: React.MouseEvent<HTMLButtonElement>) => {
      const rect = btnRef.current?.getBoundingClientRect();
      if (rect) {
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const id = ++rippleId.current;
        setRipples((prev) => [...prev, { id, x, y }]);
        setTimeout(() => {
          setRipples((prev) => prev.filter((r) => r.id !== id));
        }, 800);
      }
      onTap();
    },
    [onTap]
  );

  return (
    <div className="flex flex-col items-center justify-center py-4 relative">
      {/* Outer glow rings */}
      <div className="absolute rounded-full pointer-events-none" style={{ width: 320, height: 320, background: 'radial-gradient(circle, var(--primary-light) 0%, transparent 70%)', opacity: 0.15, filter: 'blur(20px)' }} />
      <div className="absolute rounded-full pointer-events-none animate-pulse-ring" style={{ width: 280, height: 280, border: '2px solid var(--accent)', opacity: 0.2 }} />
      <div className="absolute rounded-full pointer-events-none" style={{ width: 260, height: 260, boxShadow: '0 0 60px var(--primary-light), 0 0 120px var(--primary)', opacity: 0.3 }} />

      <button
        ref={btnRef}
        onClick={handleClick}
        className="tasbeeh-btn relative overflow-hidden"
      >
        {ripples.map((r) => (
          <span
            key={r.id}
            className="absolute rounded-full bg-white/20 animate-ping pointer-events-none"
            style={{
              left: r.x - 20,
              top: r.y - 20,
              width: 40,
              height: 40,
            }}
          />
        ))}
        <span className="btn-text leading-relaxed text-center" style={{ fontSize: '2.2rem' }}>
          أستغفر الله
        </span>
        <span className="absolute -top-3 -right-3 w-14 h-14 rounded-full flex items-center justify-center text-xl font-black shadow-lg" style={{ background: 'var(--accent)', color: 'var(--bg-dark)' }}>
          <motion.span
            key={count}
            initial={{ scale: 1.3 }}
            animate={{ scale: 1 }}
            className="tabular-nums"
          >
            {count}
          </motion.span>
        </span>
      </button>
    </div>
  );
}
