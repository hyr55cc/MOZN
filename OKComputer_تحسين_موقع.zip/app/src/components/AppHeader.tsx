import { useLanguage } from "@/hooks/useLanguage";
import { Moon, Wifi, LogOut } from "lucide-react";
import LanguageSwitcher from "./LanguageSwitcher";
import ThemeSwitcher from "./ThemeSwitcher";

interface AppHeaderProps {
  name?: string;
  isOnline?: boolean;
  onLogout?: () => void;
}

export default function AppHeader({ name, isOnline = true, onLogout }: AppHeaderProps) {
  const { t } = useLanguage();

  return (
    <header className="relative z-10 px-4 pt-5 pb-2">
      <div className="max-w-4xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-2">
          {isOnline ? (
            <span className="flex items-center gap-1 text-xs text-green-400 bg-green-400/10 px-2 py-1 rounded-full">
              <Wifi className="w-3 h-3" />
              <span>{t("connected")}</span>
            </span>
          ) : (
            <span className="flex items-center gap-1 text-xs text-yellow-400 bg-yellow-400/10 px-2 py-1 rounded-full">
              <Wifi className="w-3 h-3" />
              Offline
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          <ThemeSwitcher />
          <LanguageSwitcher />
          {name && onLogout && (
            <button
              onClick={onLogout}
              className="p-1.5 rounded-lg bg-tasbeeh-bg-dark/60 text-tasbeeh-text-muted hover:text-red-400 transition-colors"
              title={t("logout")}
            >
              <LogOut className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      <div className="max-w-4xl mx-auto text-center mt-4">
        <div className="flex items-center justify-center gap-2 mb-1">
          <h1 className="text-4xl font-black tracking-wide" style={{ color: "var(--accent)" }}>
            {t("title")}
          </h1>
          <Moon className="w-6 h-6" style={{ color: "var(--accent)" }} />
        </div>
        <p className="text-sm" style={{ color: "var(--text-secondary)" }}>
          {t("subtitle")}
        </p>
        {name && (
          <p className="text-xs mt-2" style={{ color: "var(--accent)", opacity: 0.8 }}>
            {t("welcomeBack")}, {name}
          </p>
        )}
      </div>
    </header>
  );
}
