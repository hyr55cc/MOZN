import { useLanguage } from "@/hooks/useLanguage";
import { Globe, Trophy, Flame, Clock } from "lucide-react";
import { motion } from "framer-motion";

interface StatsBarProps {
  worldTotal: number;
  total: number;
  streak: number;
  todayCount: number;
}

export default function StatsBar({ worldTotal, total, streak, todayCount }: StatsBarProps) {
  const { t } = useLanguage();

  const stats = [
    { icon: Globe, value: worldTotal.toLocaleString(), label: t("world") },
    { icon: Trophy, value: total.toLocaleString(), label: t("total") },
    { icon: Flame, value: streak, label: t("streak") },
    { icon: Clock, value: todayCount, label: t("todayCount") },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
      {stats.map((stat, i) => (
        <motion.div
          key={stat.label}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.1 }}
          className="glass-card p-4 text-center"
        >
          <div className="stat-value">{stat.value}</div>
          <div className="stat-label flex items-center justify-center gap-1 mt-1">
            <stat.icon className="w-3.5 h-3.5 text-tasbeeh-accent" />
            {stat.label}
          </div>
        </motion.div>
      ))}
    </div>
  );
}
