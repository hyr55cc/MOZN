import { useState, useCallback, useEffect, useRef } from "react";
import { useLanguage } from "@/hooks/useLanguage";
import { useTheme } from "@/hooks/useTheme";
import { useUserData } from "@/hooks/useUserData";
import ParticleBackground from "@/components/ParticleBackground";
import AppHeader from "@/components/AppHeader";
import StatsBar from "@/components/StatsBar";
import UserCard from "@/components/UserCard";
import TasbeehButton from "@/components/TasbeehButton";
import Leaderboard from "@/components/Leaderboard";
import WeeklyChart from "@/components/WeeklyChart";
import WelcomeScreen from "@/components/WelcomeScreen";

export default function Home() {
  const { dir } = useLanguage();
  const { theme } = useTheme();
  void theme;
  const { user, initUser, increment, setGoal, getWeeklyData, getFilteredLeaderboard, reset } = useUserData();
  const [leaderboardFilter, setLeaderboardFilter] = useState<"today" | "week" | "month" | "all">("today");
  const [showWelcome, setShowWelcome] = useState(!user);
  const [flashUser, setFlashUser] = useState(false);
  const prevCount = useRef(0);

  useEffect(() => {
    document.documentElement.dir = dir;
  }, [dir]);

  // White flash on current user when count increases
  useEffect(() => {
    if (user && user.todayCount > prevCount.current) {
      setFlashUser(true);
      const timer = setTimeout(() => setFlashUser(false), 400);
      prevCount.current = user.todayCount;
      return () => clearTimeout(timer);
    }
  }, [user?.todayCount]);

  const handleStart = useCallback(
    (name: string) => {
      initUser(name);
      setShowWelcome(false);
    },
    [initUser]
  );

  const handleLogout = useCallback(() => {
    reset();
    setShowWelcome(true);
  }, [reset]);

  const handleIncrement = useCallback(() => {
    increment();
  }, [increment]);

  if (showWelcome && !user) {
    return (
      <div className="min-h-screen relative overflow-hidden" style={{ background: "var(--bg-dark)" }} dir={dir}>
        <ParticleBackground />
        <WelcomeScreen onStart={handleStart} />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen relative overflow-hidden" style={{ background: "var(--bg-dark)" }} dir={dir}>
        <ParticleBackground />
        <WelcomeScreen onStart={handleStart} />
      </div>
    );
  }

  const weeklyData = getWeeklyData();
  const leaderboardData = getFilteredLeaderboard(leaderboardFilter);
  const currentRank = leaderboardData.find((u) => u.id === "me")?.rank ?? leaderboardData.length;

  const worldTotal = 3250 + user.todayCount;

  return (
    <div className="min-h-screen relative overflow-hidden pb-24" style={{ background: "var(--bg-dark)" }} dir={dir}>
      <ParticleBackground />
      <AppHeader name={user.name} onLogout={handleLogout} />

      <main className="relative z-10 max-w-4xl mx-auto px-4">
        <StatsBar
          worldTotal={worldTotal}
          total={user.totalCount}
          streak={user.streak}
          todayCount={user.todayCount}
        />

        <TasbeehButton count={user.todayCount} onTap={handleIncrement} />

        <div className="mt-4">
          <UserCard
            name={user.name}
            todayCount={user.todayCount}
            dailyGoal={user.dailyGoal}
            streak={user.streak}
            hourlyCount={user.hourlyCount}
            totalCount={user.totalCount}
            level={user.level}
            rank={currentRank}
            onSetGoal={setGoal}
            flash={flashUser}
          />
        </div>

        <WeeklyChart data={weeklyData} />

        <Leaderboard
          data={leaderboardData}
          currentUserId="me"
          activeFilter={leaderboardFilter}
          onFilterChange={setLeaderboardFilter}
        />
      </main>
    </div>
  );
}
